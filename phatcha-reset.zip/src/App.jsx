import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import { supabase } from './lib/supabaseClient';

import MessageAlert from './components/MessageAlert';
import Login from './pages/Login';
import Register from './pages/Register';
import Forgot from './pages/Forgot';
import ResetPassword from './pages/ResetPassword';
import Dashboard from './pages/Dashboard';

function AppInner() {
  const [view, setView] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      setUser(data.user ?? null);
      if (data.user) navigate('/dashboard');
    })();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) navigate('/dashboard');
    });

    return () => {
      listener?.subscription?.unsubscribe?.();
    };
  }, []);

  const showMessage = (type, text, timeout = 5000) => {
    setMessage({ type, text });
    setTimeout(()=>setMessage({ type: '', text: '' }), timeout);
  };

  const validateEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  const handleLogin = async () => {
    if (!email || !password) { showMessage('error','กรุณากรอกข้อมูลให้ครบ'); return; }
    if (!validateEmail(email)) { showMessage('error','รูปแบบอีเมลไม่ถูกต้อง'); return; }
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) showMessage('error', error.message);
    else { setUser(data.user); navigate('/dashboard'); showMessage('success','เข้าสู่ระบบสำเร็จ'); }
  };

  const handleRegister = async () => {
    if (!fullName || !email || !password || !confirmPassword) { showMessage('error','กรุณากรอกข้อมูลให้ครบ'); return; }
    if (!validateEmail(email)) { showMessage('error','รูปแบบอีเมลไม่ถูกต้อง'); return; }
    if (password !== confirmPassword) { showMessage('error','รหัสผ่านไม่ตรงกัน'); return; }
    if (password.length < 6) { showMessage('error','รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร'); return; }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email, password, options: { data: { full_name: fullName } }
    });
    setLoading(false);
    if (error) showMessage('error', error.message);
    else { showMessage('success','ลงทะเบียนสำเร็จ! ตรวจสอบอีเมลเพื่อยืนยัน'); setEmail(''); setPassword(''); setConfirmPassword(''); setFullName(''); setView('login'); }
  };

  const handleForgot = async () => {
    if (!email) { showMessage('error','กรุณากรอกอีเมล'); return; }
    if (!validateEmail(email)) { showMessage('error','รูปแบบอีเมลไม่ถูกต้อง'); return; }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
    setLoading(false);
    if (error) showMessage('error', error.message);
    else { showMessage('success','ส่งลิงก์รีเซ็ตรหัสผ่านแล้ว'); setTimeout(()=>setView('login'), 2000); }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setEmail(''); setPassword(''); setFullName('');
    showMessage('success','ออกจากระบบสำเร็จ');
    navigate('/');
  };

  const handleKeyPress = (e, action) => {
    if (e.key === 'Enter') action();
  };

  return (
    <>
      <MessageAlert message={message} />

      <Routes>
        <Route path="/" element={
          <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 flex items-center justify-center p-4">
            <div className="bg-white/80 backdrop-blur-lg rounded-3xl shadow-2xl overflow-hidden w-full max-w-md">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-8 text-white">
                <h1 className="text-3xl font-bold mb-2">{view === 'login' ? 'เข้าสู่ระบบ' : view === 'register' ? 'ลงทะเบียน' : 'ลืมรหัสผ่าน'}</h1>
                <p className="text-purple-100">{view === 'login' ? 'ยินดีต้อนรับกลับมา!' : view === 'register' ? 'สร้างบัญชีใหม่' : 'รีเซ็ตรหัสผ่านของคุณ'}</p>
              </div>
              <div className="p-8">
                {view === 'login' && <Login email={email} setEmail={setEmail} password={password} setPassword={setPassword} showPassword={showPassword} setShowPassword={setShowPassword} onLogin={handleLogin} onSwitch={(v)=>setView(v)} loading={loading} handleKeyPress={handleKeyPress} />}
                {view === 'register' && <Register fullName={fullName} setFullName={setFullName} email={email} setEmail={setEmail} password={password} setPassword={setPassword} confirmPassword={confirmPassword} setConfirmPassword={setConfirmPassword} showPassword={showPassword} setShowPassword={setShowPassword} onRegister={handleRegister} onSwitch={(v)=>setView(v)} loading={loading} handleKeyPress={handleKeyPress} />}
                {view === 'forgot' && <Forgot email={email} setEmail={setEmail} onForgot={handleForgot} loading={loading} handleKeyPress={handleKeyPress} />}
              </div>
            </div>
          </div>
        }/>

        <Route path="/reset-password" element={<div className="min-h-screen flex items-center justify-center p-6"><ResetPassword onSuccess={()=>{ showMessage('success','เปลี่ยนรหัสผ่านเรียบร้อยแล้ว'); setTimeout(()=>window.location.href='/',1500); }} /></div>} />

        <Route path="/dashboard" element={<Dashboard user={user} onLogout={handleLogout} />} />
      </Routes>
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppInner />
    </BrowserRouter>
  );
}