import React from 'react';

export default function Register({ fullName, setFullName, email, setEmail, password, setPassword, confirmPassword, setConfirmPassword, showPassword, setShowPassword, onRegister, onSwitch, loading, handleKeyPress }) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-center">สร้างบัญชีใหม่</h2>

      <input value={fullName} onChange={(e)=>setFullName(e.target.value)} placeholder="ชื่อ-นามสกุล" className="w-full pl-3 pr-3 py-2 border rounded-lg"/>
      <input value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="you@example.com" className="w-full pl-3 pr-3 py-2 border rounded-lg"/>
      <div className="relative">
        <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="รหัสผ่าน" className="w-full pl-3 pr-12 py-2 border rounded-lg"/>
        <button type="button" onClick={()=>setShowPassword(s=>!s)} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">{showPassword ? 'Hide' : 'Show'}</button>
      </div>
      <input type="password" value={confirmPassword} onChange={(e)=>setConfirmPassword(e.target.value)} placeholder="ยืนยันรหัสผ่าน" className="w-full pl-3 pr-3 py-2 border rounded-lg" onKeyPress={(e)=>handleKeyPress(e, onRegister)}/>

      <button onClick={onRegister} disabled={loading} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-xl">
        {loading ? 'กำลังสร้าง...' : 'สร้างบัญชี'}
      </button>

      <div className="text-center text-sm text-gray-600">
        มีบัญชีแล้ว? <button onClick={()=>onSwitch('login')} className="text-purple-600 font-semibold">เข้าสู่ระบบ</button>
      </div>
    </div>
  );
}