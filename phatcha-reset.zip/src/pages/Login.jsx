import React from 'react';

export default function Login({ email, setEmail, password, setPassword, showPassword, setShowPassword, onLogin, onSwitch, loading, handleKeyPress }) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-center">เข้าสู่ระบบ</h2>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">อีเมล</label>
        <div className="relative">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyPress={(e) => handleKeyPress(e, onLogin)}
            className="w-full pl-4 pr-4 py-3 border border-gray-300 rounded-xl"
            placeholder="you@example.com"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">รหัสผ่าน</label>
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyPress={(e) => handleKeyPress(e, onLogin)}
            className="w-full pl-4 pr-12 py-3 border border-gray-300 rounded-xl"
            placeholder="••••••"
          />
          <button
            type="button"
            onClick={() => setShowPassword(s => !s)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
          >
            {showPassword ? 'Hide' : 'Show'}
          </button>
        </div>
      </div>

      <div className="flex justify-end">
        <button onClick={() => onSwitch('forgot')} className="text-sm text-purple-600">ลืมรหัสผ่าน?</button>
      </div>

      <button onClick={onLogin} disabled={loading} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-xl">
        {loading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ'}
      </button>

      <div className="text-center text-sm text-gray-600">
        ยังไม่มีบัญชี? <button onClick={() => onSwitch('register')} className="text-purple-600 font-semibold">ลงทะเบียน</button>
      </div>
    </div>
  );
}